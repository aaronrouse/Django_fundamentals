from django.apps import AppConfig


class DjangoAppOneConfig(AppConfig):
    name = 'django_app_one'
