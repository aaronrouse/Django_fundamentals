from django.urls import path            #step 8 of cheat sheet
from . import views

urlpatterns = [
    path('', views.index),
    path('new', views.new),
    path('create', views.create),
    path('show', views.show),
    path('edit', views.edit),
]
