from django.shortcuts import render, redirect, HttpResponse

# Create your views here.

def index(request):
    return render(request, 'index.html')

def submit(request):
    if request.method == "POST":
        context = {
            'name': request.POST["name"],
            'language': request.POST["language"],
            'location': request.POST["location"],
            'comment':  request.POST["comment"]
        }
        return render(request, "result.html", context)
    return render(request,'result.html')